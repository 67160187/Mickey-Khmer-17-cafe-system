// models/branchModel.js — สาขาและพนักงาน
const db = require('../config/db');

const branchModel = {
  async findAll() {
    const [rows] = await db.query('SELECT branch_id, name, address FROM branch ORDER BY branch_id');
    return rows;
  },

  async findEmployees() {
    const [rows] = await db.query(
      `SELECT e.employee_id, e.name, e.role, e.branch_id, b.name AS branch_name
         FROM employee e JOIN branch b ON b.branch_id = e.branch_id
        ORDER BY e.branch_id, e.employee_id`);
    return rows;
  },

  async findEmployee(employeeId) {
    const [rows] = await db.query(
      `SELECT e.employee_id, e.name, e.role, e.branch_id, b.name AS branch_name
         FROM employee e JOIN branch b ON b.branch_id = e.branch_id
        WHERE e.employee_id = ?`, [employeeId]);
    return rows[0] || null;
  },
};

module.exports = branchModel;
