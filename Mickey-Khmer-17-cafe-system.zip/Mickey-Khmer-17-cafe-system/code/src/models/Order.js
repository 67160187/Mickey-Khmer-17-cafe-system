// src/models/Order.js — Domain class ตาม Class Diagram wk06 (Order, OrderItem, calculateTotal)
// ไม่ยุ่งกับฐานข้อมูล ทำหน้าที่คำนวณราคาอย่างเดียว

class OrderItem {
  constructor({ menuId, name, quantity, unitPrice }) {
    this.menuId = menuId;
    this.name = name;
    this.quantity = Number(quantity);
    this.unitPrice = Number(unitPrice); // ราคา snapshot ณ เวลาสั่ง (มาจาก menu_item.price เสมอ)
  }

  subtotal() {
    return round2(this.quantity * this.unitPrice);
  }
}

class Order {
  constructor({ orderId = null, items = [] } = {}) {
    this.orderId = orderId;
    this.items = [];
    items.forEach((i) => this.addItem(i));
  }

  addItem(item) {
    const orderItem = item instanceof OrderItem ? item : new OrderItem(item);
    if (!Number.isFinite(orderItem.unitPrice)) {
      // Exception flow 4a ของ UC-02: ข้อมูลราคาไม่ครบ ห้ามบันทึก
      throw new Error(`ราคาของเมนู ${orderItem.name || orderItem.menuId} ไม่ถูกต้อง`);
    }
    this.items.push(orderItem);
    return orderItem;
  }

  calculateTotal() {
    return round2(this.items.reduce((sum, i) => sum + i.subtotal(), 0));
  }

  totalQuantity() {
    return this.items.reduce((sum, i) => sum + i.quantity, 0);
  }
}

function round2(n) {
  return Math.round(n * 100) / 100;
}

module.exports = { Order, OrderItem };
