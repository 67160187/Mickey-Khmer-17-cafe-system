// models/menuModel.js — field ตรงกับ column ใน wk07-schema.sql
const db = require('../config/db');

const menuModel = {
  // menu_item: menu_id, category_id, name, price  | branch_stock: branch_id, menu_id, stock_quantity
  async findByBranch(branchId) {
    const [rows] = await db.query(
      `SELECT m.menu_id, m.category_id, c.name AS category_name,
              m.name, m.price, s.stock_quantity
         FROM branch_stock s
         JOIN menu_item m ON m.menu_id = s.menu_id
         JOIN category  c ON c.category_id = m.category_id
        WHERE s.branch_id = ?
        ORDER BY m.category_id, m.menu_id`, [branchId]);
    return rows;
  },

  async findById(menuId) {
    const [rows] = await db.query('SELECT menu_id, category_id, name, price FROM menu_item WHERE menu_id = ?', [menuId]);
    return rows[0] || null;
  },

  // ใช้ตรวจว่าเมนูนี้อยู่ในสาขาที่ส่งมาจริง (ป้องกัน IDOR ตาม wk09)
  async findInBranch(menuId, branchId) {
    const [rows] = await db.query(
      `SELECT m.menu_id, m.category_id, m.name, m.price, s.stock_quantity
         FROM branch_stock s JOIN menu_item m ON m.menu_id = s.menu_id
        WHERE s.menu_id = ? AND s.branch_id = ?`, [menuId, branchId]);
    return rows[0] || null;
  },

  async create({ categoryId, name, price }) {
    const [r] = await db.query('INSERT INTO menu_item (category_id, name, price) VALUES (?, ?, ?)', [categoryId, name, price]);
    return r.insertId;
  },

  async updatePrice(menuId, price) {           // แก้ครั้งเดียว มีผลทุกสาขา
    const [r] = await db.query('UPDATE menu_item SET price = ? WHERE menu_id = ?', [price, menuId]);
    return r.affectedRows;
  },

  // เพิ่มเมนูใหม่: เมนูเป็นแนวคิดเดียวกันทุกสาขา จึงสร้างแถว branch_stock ให้ทุกสาขา
  // สาขาที่เพิ่มได้สต็อกตามที่กรอก สาขาอื่นเริ่มที่ 0
  async createWithStock({ branchId, categoryId, name, price, stock }) {
    const conn = await db.getConnection();
    try {
      await conn.beginTransaction();
      const [r] = await conn.query(
        'INSERT INTO menu_item (category_id, name, price) VALUES (?, ?, ?)', [categoryId, name, price]);
      const menuId = r.insertId;
      const [branches] = await conn.query('SELECT branch_id FROM branch');
      for (const b of branches) {
        const qty = Number(b.branch_id) === Number(branchId) ? stock : 0;
        await conn.query(
          'INSERT INTO branch_stock (branch_id, menu_id, stock_quantity) VALUES (?, ?, ?)', [b.branch_id, menuId, qty]);
        if (qty > 0) {
          await conn.query(
            'INSERT INTO stock_movement (branch_id, menu_id, quantity_change) VALUES (?, ?, ?)', [b.branch_id, menuId, qty]);
        }
      }
      await conn.commit();
      return menuId;
    } catch (e) {
      await conn.rollback();
      throw e;
    } finally {
      conn.release();
    }
  },

  // แก้ชื่อ/หมวด/ราคา (ทุกสาขา) และตั้งสต็อกของสาขานี้ พร้อมบันทึก stock_movement ส่วนต่าง
  async update(menuId, branchId, { categoryId, name, price, stock }) {
    const conn = await db.getConnection();
    try {
      await conn.beginTransaction();
      await conn.query(
        'UPDATE menu_item SET category_id = ?, name = ?, price = ? WHERE menu_id = ?', [categoryId, name, price, menuId]);
      const [[cur]] = await conn.query(
        'SELECT stock_quantity FROM branch_stock WHERE branch_id = ? AND menu_id = ? FOR UPDATE', [branchId, menuId]);
      const diff = stock - Number(cur.stock_quantity);
      if (diff !== 0) {
        await conn.query(
          'UPDATE branch_stock SET stock_quantity = ? WHERE branch_id = ? AND menu_id = ?', [stock, branchId, menuId]);
        await conn.query(
          'INSERT INTO stock_movement (branch_id, menu_id, quantity_change) VALUES (?, ?, ?)', [branchId, menuId, diff]);
      }
      await conn.commit();
    } catch (e) {
      await conn.rollback();
      throw e;
    } finally {
      conn.release();
    }
  },

  async hasSales(menuId) {
    const [rows] = await db.query('SELECT COUNT(*) AS n FROM order_item WHERE menu_id = ?', [menuId]);
    return Number(rows[0].n) > 0;
  },

  // ลบเมนูออกจากทุกสาขา (เรียกได้เฉพาะเมนูที่ยังไม่เคยขาย เพื่อไม่ให้ประวัติการขายเสีย)
  async remove(menuId) {
    const conn = await db.getConnection();
    try {
      await conn.beginTransaction();
      await conn.query('DELETE FROM stock_movement WHERE menu_id = ?', [menuId]);
      await conn.query('DELETE FROM branch_stock WHERE menu_id = ?', [menuId]);
      const [r] = await conn.query('DELETE FROM menu_item WHERE menu_id = ?', [menuId]);
      await conn.commit();
      return r.affectedRows;
    } catch (e) {
      await conn.rollback();
      throw e;
    } finally {
      conn.release();
    }
  },

  async findCategories() {
    const [rows] = await db.query('SELECT category_id, name FROM category ORDER BY category_id');
    return rows;
  },

  // เมนูที่สต็อกเหลือน้อย (FR-05)
  async findLowStock(branchId, threshold) {
    const [rows] = await db.query(
      `SELECT m.menu_id, m.name, s.stock_quantity
         FROM branch_stock s JOIN menu_item m ON m.menu_id = s.menu_id
        WHERE s.branch_id = ? AND s.stock_quantity <= ?
        ORDER BY s.stock_quantity, m.name`, [branchId, threshold]);
    return rows;
  },
};

module.exports = menuModel;
