// models/reportModel.js — รายงานยอดขาย (FR-07) สาขาของออเดอร์หาได้จาก employee.branch_id
const db = require('../config/db');

// สร้างเงื่อนไขกรองสาขา (branchId = null แปลว่าทุกสาขา)
function branchFilter(branchId) {
  return branchId ? { sql: ' AND e.branch_id = ?', params: [branchId] } : { sql: '', params: [] };
}

const reportModel = {
  // ยอดขายแยกตามเมนู ตั้งแต่เวลา from
  async salesByMenu(branchId, from) {
    const f = branchFilter(branchId);
    const [rows] = await db.query(
      `SELECT m.menu_id, m.name,
              SUM(oi.quantity) AS qty,
              SUM(oi.quantity * oi.unit_price) AS revenue
         FROM order_item oi
         JOIN orders    o ON o.order_id    = oi.order_id
         JOIN employee  e ON e.employee_id = o.employee_id
         JOIN menu_item m ON m.menu_id     = oi.menu_id
        WHERE o.created_at >= ?${f.sql}
        GROUP BY m.menu_id, m.name
        ORDER BY revenue DESC, m.name`, [from, ...f.params]);
    return rows;
  },

  // จำนวนออเดอร์ทั้งหมดในช่วงเวลา
  async orderCount(branchId, from) {
    const f = branchFilter(branchId);
    const [rows] = await db.query(
      `SELECT COUNT(*) AS n
         FROM orders o JOIN employee e ON e.employee_id = o.employee_id
        WHERE o.created_at >= ?${f.sql}`, [from, ...f.params]);
    return Number(rows[0].n);
  },

  // สรุปยอดของแต่ละสาขา (ให้เจ้าของร้านเทียบทุกสาขา)
  async salesByBranch(from) {
    const [rows] = await db.query(
      `SELECT b.branch_id, b.name,
              COUNT(DISTINCT o.order_id) AS orders,
              COALESCE(SUM(oi.quantity * oi.unit_price), 0) AS revenue
         FROM branch b
         LEFT JOIN employee   e  ON e.branch_id   = b.branch_id
         LEFT JOIN orders     o  ON o.employee_id = e.employee_id AND o.created_at >= ?
         LEFT JOIN order_item oi ON oi.order_id   = o.order_id
        GROUP BY b.branch_id, b.name
        ORDER BY b.branch_id`, [from]);
    return rows;
  },

  // ออเดอร์ล่าสุด เพื่อให้เห็นว่าออเดอร์ใหม่เข้ามาทันที
  async recentOrders(branchId, from, limit = 8) {
    const f = branchFilter(branchId);
    const [rows] = await db.query(
      `SELECT o.order_id, o.created_at, o.payment_method,
              e.name AS employee_name, b.name AS branch_name,
              SUM(oi.quantity) AS qty,
              SUM(oi.quantity * oi.unit_price) AS total
         FROM orders o
         JOIN employee   e  ON e.employee_id = o.employee_id
         JOIN branch     b  ON b.branch_id   = e.branch_id
         JOIN order_item oi ON oi.order_id   = o.order_id
        WHERE o.created_at >= ?${f.sql}
        GROUP BY o.order_id, o.created_at, o.payment_method, e.name, b.name
        ORDER BY o.created_at DESC, o.order_id DESC
        LIMIT ?`, [from, ...f.params, limit]);
    return rows;
  },
};

module.exports = reportModel;
