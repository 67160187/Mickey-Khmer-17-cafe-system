// models/orderModel.js — field ตรงกับ column ใน wk07-schema.sql
const db = require('../config/db');
const { httpError } = require('../httpError');

const orderModel = {
  // items: [{ menuId, quantity }] ; ราคา snapshot จาก menu_item.price ตอนสั่ง
  // ทั้งหมดอยู่ใน transaction เดียว: ถ้าขั้นใดล้มเหลว ออเดอร์และสต็อกจะย้อนกลับทั้งหมด
  // (แก้ Known Limitation ที่เขียนไว้ใน wk11-architecture.md)
  async create({ employeeId, paymentMethod, items }) {
    const conn = await db.getConnection();
    try {
      await conn.beginTransaction();

      const [[emp]] = await conn.query('SELECT employee_id, branch_id FROM employee WHERE employee_id = ?', [employeeId]);
      if (!emp) throw httpError(400, 'ไม่พบรหัสพนักงานนี้ในระบบ');

      // รวมจำนวนของเมนูเดียวกันก่อนเช็คสต็อก (ตาม wk10 input design)
      const merged = new Map();
      for (const { menuId, quantity } of items) {
        merged.set(menuId, (merged.get(menuId) || 0) + quantity);
      }

      // ล็อกแถวสต็อกด้วย FOR UPDATE แล้วตรวจว่าพอ (business logic จาก wk09)
      const lines = [];
      for (const [menuId, quantity] of merged) {
        const [[m]] = await conn.query(
          `SELECT m.menu_id, m.name, m.price, s.stock_quantity
             FROM menu_item m
             JOIN branch_stock s ON s.menu_id = m.menu_id AND s.branch_id = ?
            WHERE m.menu_id = ?
            FOR UPDATE`, [emp.branch_id, menuId]);
        if (!m) throw httpError(400, `ไม่พบเมนูรหัส ${menuId} ในสาขานี้`);
        if (m.price === null || m.price === undefined) {
          throw httpError(400, `เมนู ${m.name} ยังไม่ได้ตั้งราคา`);
        }
        const stock = Number(m.stock_quantity);
        if (stock < quantity) {
          throw httpError(409, stock === 0
            ? `เมนู ${m.name} หมดชั่วคราว`
            : `สต็อกไม่เพียงพอสำหรับเมนู ${m.name} (สั่ง ${quantity} เหลือ ${stock})`);
        }
        lines.push({ menuId, name: m.name, quantity, unitPrice: Number(m.price), remaining: stock - quantity });
      }

      const [o] = await conn.query(
        'INSERT INTO orders (employee_id, payment_method) VALUES (?, ?)', [employeeId, paymentMethod]);
      const orderId = o.insertId;

      for (const line of lines) {
        await conn.query(
          'INSERT INTO order_item (order_id, menu_id, quantity, unit_price) VALUES (?, ?, ?, ?)',
          [orderId, line.menuId, line.quantity, line.unitPrice]);
        await conn.query(
          'UPDATE branch_stock SET stock_quantity = stock_quantity - ? WHERE branch_id = ? AND menu_id = ?',
          [line.quantity, emp.branch_id, line.menuId]);
        await conn.query(
          'INSERT INTO stock_movement (branch_id, menu_id, quantity_change) VALUES (?, ?, ?)',
          [emp.branch_id, line.menuId, -line.quantity]);
      }
      await conn.commit();
      return { orderId, branchId: emp.branch_id, lines };
    } catch (e) {
      await conn.rollback();
      throw e;
    } finally {
      conn.release();
    }
  },

  // total_amount ไม่ถูกเก็บ — คำนวณสดด้วย SUM(quantity * unit_price)
  async findById(orderId) {
    const [rows] = await db.query(
      `SELECT o.order_id, o.employee_id, e.branch_id, o.payment_method, o.created_at,
              COALESCE(SUM(oi.quantity * oi.unit_price), 0) AS total_amount
         FROM orders o
         JOIN employee e        ON e.employee_id = o.employee_id
         LEFT JOIN order_item oi ON oi.order_id = o.order_id
        WHERE o.order_id = ?
        GROUP BY o.order_id, o.employee_id, e.branch_id, o.payment_method, o.created_at`, [orderId]);
    if (!rows[0]) return null;
    const [items] = await db.query(
      'SELECT order_item_id, order_id, menu_id, quantity, unit_price FROM order_item WHERE order_id = ?', [orderId]);
    return { ...rows[0], items };
  },

  // ข้อมูลสำหรับพิมพ์ใบเสร็จ (มีชื่อสาขา ชื่อพนักงาน ชื่อเมนู)
  async findReceipt(orderId) {
    const [rows] = await db.query(
      `SELECT o.order_id, o.payment_method, o.created_at,
              e.name AS employee_name, b.branch_id, b.name AS branch_name
         FROM orders o
         JOIN employee e ON e.employee_id = o.employee_id
         JOIN branch   b ON b.branch_id   = e.branch_id
        WHERE o.order_id = ?`, [orderId]);
    if (!rows[0]) return null;
    const [items] = await db.query(
      `SELECT oi.menu_id, m.name, oi.quantity, oi.unit_price
         FROM order_item oi JOIN menu_item m ON m.menu_id = oi.menu_id
        WHERE oi.order_id = ?
        ORDER BY oi.order_item_id`, [orderId]);
    return { ...rows[0], items };
  },
};

module.exports = orderModel;
