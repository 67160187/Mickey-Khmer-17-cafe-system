// ข้อผิดพลาดที่ตั้งใจส่งกลับไปให้ผู้ใช้ (มี HTTP status และข้อความภาษาไทย)
function httpError(status, message) {
  const err = new Error(message);
  err.status = status;
  return err;
}

// แปลงค่าที่รับมาเป็นจำนวนเต็มบวก ถ้าไม่ใช่ให้คืน null
function toPositiveInt(value) {
  const n = Number(value);
  return Number.isInteger(n) && n > 0 ? n : null;
}

module.exports = { httpError, toPositiveInt };
