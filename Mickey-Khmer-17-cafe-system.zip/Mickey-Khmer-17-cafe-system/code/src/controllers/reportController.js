// controllers/reportController.js — รายงานยอดขายสำหรับเจ้าของร้าน (FR-07)
const reportModel = require('../models/reportModel');
const branchModel = require('../models/branchModel');
const { httpError, toPositiveInt } = require('../httpError');

const PERIODS = {
  today: { label: 'วันนี้', daysBack: 0 },
  '7d': { label: '7 วันล่าสุด', daysBack: 6 },
  '30d': { label: '30 วันล่าสุด', daysBack: 29 },
  all: { label: 'ทั้งหมด', daysBack: null },
};

// 'YYYY-MM-DD HH:MM:SS' ตามเวลาเครื่อง (ตรงกับ CURRENT_TIMESTAMP ของ MySQL บนเครื่องเดียวกัน)
function toSqlDateTime(d) {
  const p = (n) => String(n).padStart(2, '0');
  return `${d.getFullYear()}-${p(d.getMonth() + 1)}-${p(d.getDate())} ${p(d.getHours())}:${p(d.getMinutes())}:${p(d.getSeconds())}`;
}

function periodStart(key) {
  const { daysBack } = PERIODS[key];
  if (daysBack === null) return '1970-01-01 00:00:00';
  const d = new Date();
  d.setHours(0, 0, 0, 0);
  d.setDate(d.getDate() - daysBack);
  return toSqlDateTime(d);
}

const reportController = {
  // GET /api/reports/sales?branchId=all|<id>&period=today|7d|30d|all
  async sales(req, res) {
    const period = PERIODS[req.query.period] ? req.query.period : 'today';
    let branchId = null;
    if (req.query.branchId && req.query.branchId !== 'all') {
      branchId = toPositiveInt(req.query.branchId);
      if (!branchId) throw httpError(400, 'รหัสสาขาไม่ถูกต้อง');
    }

    const from = periodStart(period);
    const [byMenu, orderCount, recent, branches] = await Promise.all([
      reportModel.salesByMenu(branchId, from),
      reportModel.orderCount(branchId, from),
      reportModel.recentOrders(branchId, from),
      branchModel.findAll(),
    ]);
    const branch = branchId ? branches.find((b) => Number(b.branch_id) === branchId) : null;
    if (branchId && !branch) throw httpError(404, 'ไม่พบสาขานี้');

    const items = byMenu.map((r) => ({ name: r.name, qty: Number(r.qty), revenue: Number(r.revenue) }));
    const total = items.reduce((t, i) => ({ qty: t.qty + i.qty, revenue: t.revenue + i.revenue }), { qty: 0, revenue: 0 });

    res.json({
      period,
      periodLabel: PERIODS[period].label,
      from,
      generatedAt: toSqlDateTime(new Date()),
      branchName: branch ? branch.name : 'ทุกสาขา',
      orderCount,
      items,
      total,
      byBranch: branchId ? [] : (await reportModel.salesByBranch(from)).map((b) => ({
        branchId: Number(b.branch_id), name: b.name, orders: Number(b.orders), revenue: Number(b.revenue),
      })),
      recent: recent.map((r) => ({
        orderId: Number(r.order_id),
        receiptNo: 'BB-' + String(r.order_id).padStart(5, '0'),
        createdAt: r.created_at,
        branchName: r.branch_name,
        employeeName: r.employee_name,
        qty: Number(r.qty),
        total: Number(r.total),
      })),
    });
  },
};

module.exports = reportController;
