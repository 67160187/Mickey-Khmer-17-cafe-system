// controllers/branchController.js — สาขา, พนักงาน และการเข้าสู่ระบบแบบเลือกบัญชีพนักงาน (FR-09 แบบย่อ)
const branchModel = require('../models/branchModel');
const { httpError, toPositiveInt } = require('../httpError');

function toEmployeeJson(e) {
  return {
    employeeId: Number(e.employee_id),
    name: e.name,
    role: e.role,
    branchId: Number(e.branch_id),
    branchName: e.branch_name,
  };
}

const branchController = {
  // GET /api/branches
  async branches(req, res) {
    const rows = await branchModel.findAll();
    res.json(rows.map((b) => ({ branchId: Number(b.branch_id), name: b.name, address: b.address })));
  },

  // GET /api/employees
  async employees(req, res) {
    const rows = await branchModel.findEmployees();
    res.json(rows.map(toEmployeeJson));
  },

  // POST /api/login  body: { employeeId }
  async login(req, res) {
    const employeeId = toPositiveInt(req.body.employeeId);
    if (!employeeId) throw httpError(400, 'กรุณาเลือกพนักงาน');
    const emp = await branchModel.findEmployee(employeeId);
    if (!emp) throw httpError(401, 'ไม่พบบัญชีพนักงานนี้');
    res.json(toEmployeeJson(emp));
  },
};

module.exports = branchController;
