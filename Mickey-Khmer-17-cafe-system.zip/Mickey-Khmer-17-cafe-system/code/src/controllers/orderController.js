// controllers/orderController.js — รับออเดอร์ (UC-02, US-01, US-02) และใบเสร็จ (FR-08)
const orderModel = require('../models/orderModel');
const { Order } = require('../models/Order');
const { httpError, toPositiveInt } = require('../httpError');

const LOW_STOCK = Number(process.env.LOW_STOCK_THRESHOLD || 10);
const PAYMENT_METHODS = { CASH: 'เงินสด', QR: 'QR Code' };

function receiptNo(orderId) {
  return 'BB-' + String(orderId).padStart(5, '0');
}

const orderController = {
  // POST /api/orders  body: { employeeId, paymentMethod, items: [{ menuId, quantity }] }
  async create(req, res) {
    const employeeId = toPositiveInt(req.body.employeeId);
    const paymentMethod = String(req.body.paymentMethod || '').toUpperCase();
    const rawItems = Array.isArray(req.body.items) ? req.body.items : [];

    if (!employeeId) throw httpError(400, 'กรุณาเข้าสู่ระบบด้วยบัญชีพนักงานก่อนรับออเดอร์');
    if (!PAYMENT_METHODS[paymentMethod]) throw httpError(400, 'กรุณาเลือกวิธีชำระเงิน (เงินสด หรือ QR Code)');
    if (rawItems.length === 0) throw httpError(400, 'ยังไม่มีรายการในออเดอร์');

    // client ส่งแค่ menuId กับ quantity ราคาดึงจากฐานข้อมูลเสมอ (wk09 หัวข้อ 3.1)
    const items = rawItems.map((i) => {
      const menuId = toPositiveInt(i.menuId);
      const quantity = toPositiveInt(i.quantity);
      if (!menuId || !quantity || quantity > 999) throw httpError(400, 'รายการเมนูหรือจำนวนไม่ถูกต้อง');
      return { menuId, quantity };
    });

    const result = await orderModel.create({ employeeId, paymentMethod, items });

    // ใช้ Domain class Order (wk06) คำนวณยอดรวม
    const order = new Order({ orderId: result.orderId, items: result.lines });

    res.status(201).json({
      orderId: result.orderId,
      receiptNo: receiptNo(result.orderId),
      total: order.calculateTotal(),
      // แจ้งเตือนเมนูที่เหลือน้อยหลังขาย (FR-05)
      lowStock: result.lines
        .filter((l) => l.remaining <= LOW_STOCK)
        .map((l) => ({ menuId: l.menuId, name: l.name, remaining: l.remaining })),
    });
  },

  // GET /api/orders/:id  (ข้อมูลใบเสร็จ)
  async receipt(req, res) {
    const orderId = toPositiveInt(req.params.id);
    if (!orderId) throw httpError(400, 'เลขที่ออเดอร์ไม่ถูกต้อง');
    const data = await orderModel.findReceipt(orderId);
    if (!data) throw httpError(404, 'ไม่พบออเดอร์นี้');

    const order = new Order({
      orderId,
      items: data.items.map((i) => ({
        menuId: Number(i.menu_id), name: i.name, quantity: i.quantity, unitPrice: i.unit_price,
      })),
    });

    res.json({
      orderId,
      receiptNo: receiptNo(orderId),
      branchName: data.branch_name,
      employeeName: data.employee_name,
      createdAt: data.created_at,
      paymentMethod: data.payment_method,
      paymentLabel: PAYMENT_METHODS[data.payment_method] || data.payment_method,
      items: order.items.map((i) => ({
        name: i.name, quantity: i.quantity, unitPrice: i.unitPrice, subtotal: i.subtotal(),
      })),
      total: order.calculateTotal(),
    });
  },
};

module.exports = orderController;
