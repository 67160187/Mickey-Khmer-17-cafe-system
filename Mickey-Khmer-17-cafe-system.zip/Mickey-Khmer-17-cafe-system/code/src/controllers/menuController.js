// controllers/menuController.js — เมนูและสต็อก (ส่ง branchId ทุก request ตาม wk09/wk10)
const menuModel = require('../models/menuModel');
const { httpError, toPositiveInt } = require('../httpError');

const LOW_STOCK = Number(process.env.LOW_STOCK_THRESHOLD || 10);

function requireBranch(value) {
  const branchId = toPositiveInt(value);
  if (!branchId) throw httpError(400, 'ต้องระบุสาขา (branchId)');
  return branchId;
}

// ตรวจข้อมูลฟอร์มเพิ่ม/แก้ไขเมนู (server ตรวจซ้ำเสมอ ไม่เชื่อ client)
function parseMenuBody(body) {
  const name = String(body.name || '').trim();
  const categoryId = toPositiveInt(body.categoryId);
  const price = Number(body.price);
  const stock = Number(body.stock ?? 0);
  if (!name || name.length > 100) throw httpError(400, 'กรุณากรอกชื่อเมนู (ไม่เกิน 100 ตัวอักษร)');
  if (!categoryId) throw httpError(400, 'กรุณาเลือกหมวดหมู่');
  if (!Number.isFinite(price) || price <= 0 || price > 99999) throw httpError(400, 'ราคาต้องเป็นตัวเลขมากกว่า 0');
  if (!Number.isInteger(stock) || stock < 0) throw httpError(400, 'สต็อกต้องเป็นจำนวนเต็มตั้งแต่ 0 ขึ้นไป');
  return { name, categoryId, price: Math.round(price * 100) / 100, stock };
}

function toMenuJson(row) {
  const stock = Number(row.stock_quantity);
  return {
    menuId: Number(row.menu_id),
    categoryId: Number(row.category_id),
    categoryName: row.category_name,
    name: row.name,
    price: Number(row.price),
    stock,
    lowStock: stock > 0 && stock <= LOW_STOCK,
    soldOut: stock <= 0,
  };
}

const menuController = {
  // GET /api/menu?branchId=
  async list(req, res) {
    const branchId = requireBranch(req.query.branchId);
    const rows = await menuModel.findByBranch(branchId);
    res.json({ lowStockThreshold: LOW_STOCK, items: rows.map(toMenuJson) });
  },

  // GET /api/menu/low-stock?branchId=
  async lowStock(req, res) {
    const branchId = requireBranch(req.query.branchId);
    const rows = await menuModel.findLowStock(branchId, LOW_STOCK);
    res.json(rows.map((r) => ({ menuId: Number(r.menu_id), name: r.name, stock: Number(r.stock_quantity) })));
  },

  // GET /api/categories
  async categories(req, res) {
    const rows = await menuModel.findCategories();
    res.json(rows.map((r) => ({ categoryId: Number(r.category_id), name: r.name })));
  },

  // POST /api/menu
  async create(req, res) {
    const branchId = requireBranch(req.body.branchId);
    const data = parseMenuBody(req.body);
    const menuId = await menuModel.createWithStock({ branchId, ...data });
    res.status(201).json({ menuId, message: `เพิ่มเมนู ${data.name} แล้ว` });
  },

  // PUT /api/menu/:id
  async update(req, res) {
    const menuId = toPositiveInt(req.params.id);
    const branchId = requireBranch(req.body.branchId);
    if (!menuId) throw httpError(400, 'รหัสเมนูไม่ถูกต้อง');
    const existing = await menuModel.findInBranch(menuId, branchId);
    if (!existing) throw httpError(404, 'ไม่พบเมนูนี้ในสาขาที่เลือก');
    const data = parseMenuBody(req.body);
    await menuModel.update(menuId, branchId, data);
    res.json({ menuId, message: `บันทึกเมนู ${data.name} แล้ว` });
  },

  // DELETE /api/menu/:id?branchId=
  async remove(req, res) {
    const menuId = toPositiveInt(req.params.id);
    const branchId = requireBranch(req.query.branchId);
    if (!menuId) throw httpError(400, 'รหัสเมนูไม่ถูกต้อง');
    const existing = await menuModel.findInBranch(menuId, branchId);
    if (!existing) throw httpError(404, 'ไม่พบเมนูนี้ในสาขาที่เลือก');
    if (await menuModel.hasSales(menuId)) {
      throw httpError(409, `เมนู ${existing.name} มีประวัติการขายแล้ว จึงลบไม่ได้ ให้ตั้งสต็อกเป็น 0 แทน`);
    }
    await menuModel.remove(menuId);
    res.json({ message: `ลบเมนู ${existing.name} แล้ว` });
  },
};

module.exports = menuController;
