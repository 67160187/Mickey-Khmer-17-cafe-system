// src/config/db.js — connection pool ไปยัง MySQL (ตาม Architecture wk11)
require('dotenv').config();
const mysql = require('mysql2/promise');

// ใช้ pool แทนการเปิด connection ใหม่ทุก request เพื่อลด overhead
const pool = mysql.createPool({
  host: process.env.DB_HOST || 'localhost',
  port: Number(process.env.DB_PORT || 3306),
  user: process.env.DB_USER || 'root',
  password: process.env.DB_PASSWORD || '',
  database: process.env.DB_NAME || 'cafe_pos',
  waitForConnections: true,
  connectionLimit: 10,
  dateStrings: true, // คืนวันที่เป็นข้อความ 'YYYY-MM-DD HH:MM:SS' ตามเวลาเครื่อง
});

module.exports = pool;
