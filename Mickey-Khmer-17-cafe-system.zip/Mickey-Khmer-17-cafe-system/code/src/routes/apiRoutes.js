// routes/apiRoutes.js — รวม endpoint ทั้งหมดของระบบ
const express = require('express');
const menuController = require('../controllers/menuController');
const orderController = require('../controllers/orderController');
const reportController = require('../controllers/reportController');
const branchController = require('../controllers/branchController');

const router = express.Router();

// Express 4 ไม่จับ error ของ async function ให้เอง จึงห่อไว้ส่งต่อไปที่ error handler
const wrap = (fn) => (req, res, next) => Promise.resolve(fn(req, res, next)).catch(next);

// สาขา / พนักงาน / เข้าสู่ระบบ
router.get('/branches', wrap(branchController.branches));
router.get('/employees', wrap(branchController.employees));
router.post('/login', wrap(branchController.login));

// เมนูและสต็อก
router.get('/categories', wrap(menuController.categories));
router.get('/menu', wrap(menuController.list));
router.get('/menu/low-stock', wrap(menuController.lowStock));
router.post('/menu', wrap(menuController.create));
router.put('/menu/:id', wrap(menuController.update));
router.delete('/menu/:id', wrap(menuController.remove));

// ออเดอร์และใบเสร็จ
router.post('/orders', wrap(orderController.create));
router.get('/orders/:id', wrap(orderController.receipt));

// รายงาน
router.get('/reports/sales', wrap(reportController.sales));

module.exports = router;
