// src/app.js — จุดเริ่มของ Application Server (Node.js / Express, port 3000)
require('dotenv').config();
const path = require('path');
const express = require('express');
const apiRoutes = require('./routes/apiRoutes');

const app = express();
app.use(express.json());
app.use(express.static(path.join(__dirname, '..', 'public')));

app.use('/api', apiRoutes);

// endpoint ที่ไม่มีอยู่
app.use('/api', (req, res) => res.status(404).json({ error: 'ไม่พบ endpoint นี้' }));

// error handler กลาง: ข้อผิดพลาดที่ตั้งใจ (มี status) ส่งข้อความไทยกลับไป ที่เหลือเป็น 500
// eslint-disable-next-line no-unused-vars
app.use((err, req, res, next) => {
  if (err.type === 'entity.parse.failed') {
    return res.status(400).json({ error: 'ข้อมูลที่ส่งมาไม่ใช่ JSON ที่ถูกต้อง' });
  }
  if (err.status) return res.status(err.status).json({ error: err.message });
  console.error(err);
  if (err.code === 'ECONNREFUSED' || err.code === 'ER_ACCESS_DENIED_ERROR' || err.code === 'ER_BAD_DB_ERROR') {
    return res.status(500).json({ error: 'เชื่อมต่อฐานข้อมูลไม่ได้ ตรวจว่าเปิด MySQL และรัน npm run setup-db แล้ว' });
  }
  res.status(500).json({ error: 'เกิดข้อผิดพลาดในระบบ ลองใหม่อีกครั้ง' });
});

const PORT = Number(process.env.PORT || 3000);
app.listen(PORT, () => {
  console.log(`Brew & Bean POS พร้อมใช้งานที่ http://localhost:${PORT}`);
});
