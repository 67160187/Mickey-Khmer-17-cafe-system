// js/pos.js — หน้ารับออเดอร์ (UC-02 / US-01 / US-02)
(async function () {
  const el = (id) => document.getElementById(id);
  const statusEl = el('status');

  let session;
  let menu = [];               // เมนูของสาขา [{menuId, name, price, stock, ...}]
  let lowThreshold = 10;
  let activeCategory = 'all';
  const picks = {};            // จำนวนที่ตั้งไว้บนการ์ดแต่ละใบ (default 1)
  const cart = new Map();      // menuId -> quantity
  let busy = false;

  try {
    ({ session } = await App.initHeader({ mode: 'locked' }));
  } catch (e) {
    if (e.message !== 'not logged in') App.setStatus(statusEl, 'err', e.message);
    return;
  }

  async function loadMenu() {
    const data = await App.api(`/menu?branchId=${session.branchId}`);
    menu = data.items;
    lowThreshold = data.lowStockThreshold;
    // ถ้าสต็อกลดลงจนน้อยกว่าที่อยู่ในรายการ ให้ปรับจำนวนในรายการลง
    for (const [id, q] of cart) {
      const m = menu.find((x) => x.menuId === id);
      if (!m || m.stock <= 0) cart.delete(id);
      else if (q > m.stock) cart.set(id, m.stock);
    }
    renderTabs();
    renderCards();
    renderCart();
    renderLowStock();
  }

  function renderLowStock() {
    const low = menu.filter((m) => m.stock <= lowThreshold).sort((a, b) => a.stock - b.stock);
    el('lowStockAlert').innerHTML = low.length
      ? `<span>⚠️</span><div><strong>สต็อกใกล้หมด:</strong> ` +
        low.map((m) => `${App.esc(m.name)} (${m.stock === 0 ? 'หมด' : 'เหลือ ' + m.stock})`).join(', ') + '</div>'
      : '';
  }

  function renderTabs() {
    const cats = [...new Map(menu.map((m) => [m.categoryId, m.categoryName])).entries()];
    el('tabs').innerHTML = [['all', 'ทั้งหมด'], ...cats]
      .map(([id, name]) => `<button class="tab ${String(id) === String(activeCategory) ? 'active' : ''}" data-cat="${id}">${App.esc(name)}</button>`)
      .join('');
  }

  function stockLabel(m) {
    if (m.stock <= 0) return '<span class="stock-tag out">หมดชั่วคราว</span>';
    if (m.stock <= lowThreshold) return `<span class="stock-tag low">เหลือ ${m.stock} · ใกล้หมด</span>`;
    return `<span class="stock-tag">เหลือ ${m.stock}</span>`;
  }

  function renderCards() {
    const list = menu.filter((m) => activeCategory === 'all' || String(m.categoryId) === String(activeCategory));
    el('cards').innerHTML = list.map((m) => {
      const out = m.stock <= 0;
      const q = picks[m.menuId] || 1;
      return `
        <article class="panel menu-card ${out ? 'soldout' : ''}" data-id="${m.menuId}">
          <div class="top">
            <div class="pic">${App.emoji(m.categoryName, m.name)}</div>
            <div><h3>${App.esc(m.name)}</h3><div class="price num">${App.money(m.price)} บาท</div></div>
          </div>
          <div class="row">
            ${stockLabel(m)}
            <div class="stepper">
              <button type="button" data-act="dec" ${out || q <= 1 ? 'disabled' : ''} aria-label="ลดจำนวน">−</button>
              <input type="number" min="1" step="1" value="${q}" data-act="qty" ${out ? 'disabled' : ''} aria-label="จำนวน">
              <button type="button" data-act="inc" ${out ? 'disabled' : ''} aria-label="เพิ่มจำนวน">+</button>
            </div>
          </div>
          <button class="btn btn-sm btn-block" type="button" data-act="add" ${out ? 'disabled' : ''}>
            ${out ? 'เมนูนี้หมดชั่วคราว' : '+ เพิ่มลงรายการ'}
          </button>
        </article>`;
    }).join('') || '<p class="muted">ไม่มีเมนูในหมวดนี้</p>';
  }

  function renderCart() {
    const rows = [...cart.entries()].map(([id, q]) => {
      const m = menu.find((x) => x.menuId === id);
      return { ...m, q, sub: m.price * q };
    });
    el('cart').innerHTML = rows.length
      ? rows.map((r) => `
          <tr data-id="${r.menuId}">
            <td><strong>${App.esc(r.name)}</strong><div class="muted small num">${App.money(r.price)} × ${r.q}</div></td>
            <td class="r"><span class="qty-mini">
              <button type="button" data-act="cdec" aria-label="ลด">−</button>
              <span class="num">${r.q}</span>
              <button type="button" data-act="cinc" ${r.q >= r.stock ? 'disabled' : ''} aria-label="เพิ่ม">+</button>
            </span></td>
            <td class="r num">${App.money(r.sub)}</td>
            <td class="r"><button class="icon-btn" type="button" data-act="remove">ลบ</button></td>
          </tr>`).join('')
      : '<tr><td colspan="4" class="cart-empty">ยังไม่มีรายการ<br><span class="small">กดเลือกเมนูทางซ้ายเพื่อเริ่มออเดอร์</span></td></tr>';

    // ยอดรวมบนหน้าจอใช้แสดงผลเท่านั้น ราคาจริงคำนวณใหม่ที่ server เสมอ
    const total = rows.reduce((s, r) => s + r.sub, 0);
    el('total').textContent = App.money(total);
    el('clearBtn').disabled = rows.length === 0 || busy;
    updateConfirm();
  }

  function payment() {
    const p = document.querySelector('input[name="pay"]:checked');
    return p ? p.value : null;
  }

  // Error Prevention: ปุ่มยืนยันกดได้เมื่อมีรายการและเลือกวิธีชำระเงินแล้วเท่านั้น
  function updateConfirm() {
    el('payHint').textContent = payment() ? '' : '* ต้องเลือกวิธีชำระเงินก่อนยืนยัน';
    el('confirmBtn').disabled = busy || cart.size === 0 || !payment();
  }

  function addToCart(id, qty) {
    const m = menu.find((x) => x.menuId === id);
    if (!m) return;
    if (m.stock <= 0) {
      App.setStatus(statusEl, 'err', `เมนู ${m.name} หมดชั่วคราว`);
      return;
    }
    const next = (cart.get(id) || 0) + qty;
    if (next > m.stock) {
      App.setStatus(statusEl, 'warn', `เพิ่มไม่ได้: ${m.name} เหลือในสต็อก ${m.stock} (ในรายการมีแล้ว ${cart.get(id) || 0})`);
      return;
    }
    cart.set(id, next);
    picks[id] = 1;
    App.setStatus(statusEl, '', '');
    renderCards();
    renderCart();
  }

  // ----- เหตุการณ์บนการ์ดเมนู -----
  el('tabs').addEventListener('click', (e) => {
    const b = e.target.closest('[data-cat]');
    if (!b) return;
    activeCategory = b.dataset.cat;
    renderTabs();
    renderCards();
  });

  el('cards').addEventListener('click', (e) => {
    const card = e.target.closest('.menu-card');
    const act = e.target.closest('[data-act]')?.dataset.act;
    if (!card || !act) return;
    const id = Number(card.dataset.id);
    const m = menu.find((x) => x.menuId === id);
    const q = picks[id] || 1;
    if (act === 'inc') picks[id] = Math.min(q + 1, Math.max(1, m.stock));
    if (act === 'dec') picks[id] = Math.max(1, q - 1);
    if (act === 'add') return addToCart(id, q);
    if (act === 'inc' || act === 'dec') renderCards();
  });

  el('cards').addEventListener('change', (e) => {
    if (e.target.dataset.act !== 'qty') return;
    const id = Number(e.target.closest('.menu-card').dataset.id);
    const v = Math.floor(Number(e.target.value));
    picks[id] = Number.isFinite(v) && v >= 1 ? v : 1;
    renderCards();
  });

  // ----- เหตุการณ์ในรายการที่เลือก -----
  el('cart').addEventListener('click', (e) => {
    const row = e.target.closest('tr[data-id]');
    const act = e.target.closest('[data-act]')?.dataset.act;
    if (!row || !act) return;
    const id = Number(row.dataset.id);
    if (act === 'remove') cart.delete(id);
    if (act === 'cdec') { const q = cart.get(id) - 1; q <= 0 ? cart.delete(id) : cart.set(id, q); }
    if (act === 'cinc') return addToCart(id, 1);
    renderCart();
  });

  el('clearBtn').addEventListener('click', () => { cart.clear(); renderCart(); App.setStatus(statusEl, '', ''); });
  document.querySelectorAll('input[name="pay"]').forEach((r) => r.addEventListener('change', updateConfirm));

  // ----- ยืนยันออเดอร์ → POST /api/orders -----
  el('confirmBtn').addEventListener('click', async () => {
    if (busy || cart.size === 0 || !payment()) return;
    busy = true;
    updateConfirm();
    App.setStatus(statusEl, 'info', 'กำลังบันทึกออเดอร์…');
    try {
      const result = await App.api('/orders', {
        method: 'POST',
        body: {
          employeeId: session.employeeId,
          paymentMethod: payment(),
          items: [...cart.entries()].map(([menuId, quantity]) => ({ menuId, quantity })),
        },
      });
      cart.clear();
      document.querySelectorAll('input[name="pay"]').forEach((r) => { r.checked = false; });
      let msg = `บันทึกสำเร็จ ใบเสร็จ #${result.receiptNo} ยอด ${App.money(result.total)} บาท`;
      if (result.lowStock.length) {
        msg += ' · แจ้งเตือนสต็อกต่ำ: ' + result.lowStock.map((l) => `${l.name} เหลือ ${l.remaining}`).join(', ');
      }
      App.setStatus(statusEl, result.lowStock.length ? 'warn' : 'ok', msg);
      openReceipt(result.orderId);
    } catch (e) {
      App.setStatus(statusEl, 'err', 'บันทึกไม่สำเร็จ: ' + e.message);
    } finally {
      busy = false;
      await loadMenu().catch(() => {});
    }
  });

  // ----- ใบเสร็จ -----
  function openReceipt(orderId) {
    el('receiptFrame').src = `/receipt.html?id=${orderId}&embed=1`;
    el('receiptModal').classList.add('open');
    el('newOrderBtn').focus();
  }
  function closeReceipt() {
    el('receiptModal').classList.remove('open');
    el('receiptFrame').src = 'about:blank';
  }
  el('printBtn').addEventListener('click', () => el('receiptFrame').contentWindow.print());
  el('newOrderBtn').addEventListener('click', closeReceipt);
  el('receiptModal').addEventListener('click', (e) => { if (e.target.id === 'receiptModal') closeReceipt(); });
  document.addEventListener('keydown', (e) => { if (e.key === 'Escape') closeReceipt(); });

  try {
    await loadMenu();
  } catch (e) {
    el('cards').innerHTML = '';
    App.setStatus(statusEl, 'err', e.message);
  }
})();
