// js/common.js — ฟังก์ชันที่ใช้ร่วมกันทุกหน้า
const App = {
  KEY: 'bb.employee',

  session() {
    try { return JSON.parse(localStorage.getItem(this.KEY)); } catch { return null; }
  },
  setSession(emp) { localStorage.setItem(this.KEY, JSON.stringify(emp)); },
  logout() {
    localStorage.removeItem(this.KEY);
    location.href = '/login.html';
  },
  // US-03: ยังไม่เข้าสู่ระบบ → กลับไปหน้าเข้าสู่ระบบก่อน
  requireLogin() {
    const s = this.session();
    if (!s) {
      location.replace('/login.html');
      throw new Error('not logged in');
    }
    return s;
  },

  async api(path, { method = 'GET', body } = {}) {
    let res;
    try {
      res = await fetch('/api' + path, {
        method,
        headers: body ? { 'Content-Type': 'application/json' } : undefined,
        body: body ? JSON.stringify(body) : undefined,
      });
    } catch {
      throw new Error('ติดต่อเซิร์ฟเวอร์ไม่ได้ ตรวจว่ารัน npm start อยู่');
    }
    const data = await res.json().catch(() => ({}));
    if (!res.ok) throw new Error(data.error || `เกิดข้อผิดพลาด (${res.status})`);
    return data;
  },

  money(n) {
    return Number(n || 0).toLocaleString('th-TH', { minimumFractionDigits: 2, maximumFractionDigits: 2 });
  },
  int(n) { return Number(n || 0).toLocaleString('th-TH'); },

  // '2026-10-29 14:32:05' → { date: '29/10/2569', time: '14:32' }
  thaiDateTime(s) {
    const [d, t = ''] = String(s).split(' ');
    const [y, m, day] = d.split('-').map(Number);
    return { date: `${day}/${m}/${y + 543}`, time: t.slice(0, 5) };
  },

  esc(s) {
    return String(s ?? '').replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
  },

  setStatus(el, type, text) {
    el.className = 'status' + (type ? ' ' + type : '');
    el.textContent = text || '';
  },

  emoji(categoryName, name) {
    if (/ครัวซอง/.test(name)) return '🥐';
    if (/โกโก้|มอคค่า/.test(name)) return '🍫';
    if (/มัทฉะ/.test(name)) return '🍵';
    if (categoryName === 'ชา') return '🧋';
    return '☕';
  },

  // เติมแถบบน: ชื่อพนักงาน, ปุ่มออกจากระบบ, ตัวเลือกสาขา
  // mode: 'locked' = ล็อกเป็นสาขาของพนักงาน (POS) | 'select' = เลือกได้ | 'select-all' = มีตัวเลือกทุกสาขา
  async initHeader({ mode = 'select', defaultValue, onChange } = {}) {
    const s = this.requireLogin();
    document.getElementById('who').textContent = `${s.name} (${s.role})`;
    document.getElementById('logout').addEventListener('click', () => {
      if (confirm('ออกจากระบบใช่หรือไม่?')) this.logout();
    });

    const select = document.getElementById('branchSelect');
    const branches = await this.api('/branches');
    select.innerHTML =
      (mode === 'select-all' ? '<option value="all">ทุกสาขา</option>' : '') +
      branches.map((b) => `<option value="${b.branchId}">${this.esc(b.name)}</option>`).join('');
    select.value = String(defaultValue ?? s.branchId);
    if (mode === 'locked') {
      select.disabled = true;
      select.title = 'ออเดอร์จะถูกบันทึกในสาขาของพนักงานที่เข้าสู่ระบบ';
    }
    select.addEventListener('change', () => onChange && onChange(select.value));
    return { session: s, branches, select };
  },
};
