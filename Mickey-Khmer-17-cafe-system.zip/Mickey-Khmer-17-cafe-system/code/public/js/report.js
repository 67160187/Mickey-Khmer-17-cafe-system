// js/report.js — รายงานยอดขาย (FR-07) GET /api/reports/sales?branchId=&period=
(async function () {
  const el = (id) => document.getElementById(id);
  const statusEl = el('status');
  const REFRESH_MS = 5000;
  let branchValue = 'all';
  let seenOrderIds = null;   // ใช้ไฮไลต์ออเดอร์ที่เพิ่งเข้ามาใหม่
  let timer = null;

  try {
    await App.initHeader({ mode: 'select-all', defaultValue: 'all', onChange: (v) => { branchValue = v; seenOrderIds = null; load(); } });
  } catch (e) {
    if (e.message !== 'not logged in') App.setStatus(statusEl, 'err', e.message);
    return;
  }

  async function load({ quiet = false } = {}) {
    if (!quiet) App.setStatus(statusEl, 'info', 'กำลังโหลด…');
    try {
      const r = await App.api(`/reports/sales?branchId=${branchValue}&period=${el('period').value}`);
      const { date } = App.thaiDateTime(r.generatedAt);
      el('heading').textContent = `รายงานสรุปยอดขาย — สาขา: ${r.branchName} · ช่วง: ${r.periodLabel} (ข้อมูล ณ ${date})`;
      el('kRevenue').textContent = App.money(r.total.revenue);
      el('kOrders').textContent = App.int(r.orderCount);
      el('kQty').textContent = App.int(r.total.qty);

      el('menuRows').innerHTML = r.items.length
        ? r.items.map((i) => `<tr><td>${App.esc(i.name)}</td><td class="r num">${App.int(i.qty)}</td><td class="r num">${App.money(i.revenue)}</td></tr>`).join('') +
          `<tr class="total-row"><td>รวมทั้งหมด</td><td class="r num">${App.int(r.total.qty)}</td><td class="r num">${App.money(r.total.revenue)}</td></tr>`
        : '<tr><td colspan="3" class="muted">ไม่มีข้อมูลในช่วงนี้</td></tr>';

      // เทียบสาขา (แสดงเมื่อเลือก "ทุกสาขา")
      el('branchPanel').style.display = r.byBranch.length ? '' : 'none';
      const max = Math.max(1, ...r.byBranch.map((b) => b.revenue));
      el('branchRows').innerHTML = r.byBranch.map((b) => `
        <div style="margin:10px 0">
          <div style="display:flex;justify-content:space-between;gap:8px">
            <strong>${App.esc(b.name)}</strong>
            <span class="num">${App.money(b.revenue)} บาท · ${App.int(b.orders)} ออเดอร์</span>
          </div>
          <div class="bar"><i style="width:${(b.revenue / max) * 100}%"></i></div>
        </div>`).join('');

      const ids = new Set(r.recent.map((o) => o.orderId));
      el('recentRows').innerHTML = r.recent.length
        ? r.recent.map((o) => {
            const isNew = seenOrderIds && !seenOrderIds.has(o.orderId);
            const t = App.thaiDateTime(o.createdAt);
            return `<tr class="${isNew ? 'new-row' : ''}">
              <td><a href="/receipt.html?id=${o.orderId}" target="_blank" rel="noopener">#${o.receiptNo}</a></td>
              <td class="num">${t.time}${r.period === 'today' ? '' : ' · ' + t.date}</td>
              <td>${App.esc(o.branchName)}</td>
              <td class="r num">${App.money(o.total)}</td></tr>`;
          }).join('')
        : '<tr><td colspan="4" class="muted">ยังไม่มีออเดอร์</td></tr>';
      seenOrderIds = ids;

      el('updated').textContent = '· ล่าสุด ' + new Date().toLocaleTimeString('th-TH', { hour: '2-digit', minute: '2-digit', second: '2-digit' });
      App.setStatus(statusEl, '', '');
    } catch (e) {
      App.setStatus(statusEl, 'err', 'ข้อผิดพลาด: ' + e.message);
    }
  }

  // อัปเดตแบบเรียลไทม์ทุก 5 วินาที ให้เจ้าของร้านเห็นออเดอร์ใหม่ทันที
  function schedule() {
    clearInterval(timer);
    el('live').classList.toggle('off', !el('auto').checked);
    if (el('auto').checked) timer = setInterval(() => load({ quiet: true }), REFRESH_MS);
  }

  el('viewBtn').addEventListener('click', () => load());
  el('period').addEventListener('change', () => { seenOrderIds = null; load(); });
  el('auto').addEventListener('change', schedule);

  await load();
  schedule();
})();
