// js/menu.js — หน้าจัดการเมนู (CRUD /api/menu ส่ง branchId ทุก method)
(async function () {
  const el = (id) => document.getElementById(id);
  const statusEl = el('status');
  const form = el('menuForm');
  let branchId;
  let branches = [];
  let items = [];
  let editingId = null;

  try {
    const h = await App.initHeader({ mode: 'select', onChange: (v) => { branchId = Number(v); hideForm(); load(); } });
    branchId = h.session.branchId;
    branches = h.branches;
    const cats = await App.api('/categories');
    el('fCat').innerHTML = '<option value="">— เลือก —</option>' +
      cats.map((c) => `<option value="${c.categoryId}">${App.esc(c.name)}</option>`).join('');
  } catch (e) {
    if (e.message !== 'not logged in') App.setStatus(statusEl, 'err', e.message);
    return;
  }

  async function load() {
    el('branchName').textContent = branches.find((b) => b.branchId === branchId)?.name || '';
    try {
      const data = await App.api(`/menu?branchId=${branchId}`);
      items = data.items;
      el('rows').innerHTML = items.map((m) => `
        <tr data-id="${m.menuId}">
          <td><strong>${App.esc(m.name)}</strong></td>
          <td>${App.esc(m.categoryName)}</td>
          <td class="r num">${App.money(m.price)}</td>
          <td class="r num">${m.stock}
            ${m.soldOut ? ' <span class="badge out">หมด</span>' : m.lowStock ? ' <span class="badge low">ใกล้หมด</span>' : ''}</td>
          <td><div class="actions">
            <button class="btn btn-sm" data-act="edit" type="button">แก้ไข</button>
            <button class="btn btn-sm btn-danger" data-act="delete" type="button">ลบ</button>
          </div></td>
        </tr>`).join('') || '<tr><td colspan="5" class="muted">ยังไม่มีเมนู</td></tr>';
    } catch (e) {
      App.setStatus(statusEl, 'err', e.message);
    }
  }

  function clearErrors() { form.querySelectorAll('.err').forEach((x) => { x.textContent = ''; }); }
  function setErr(id, msg) { form.querySelector(`[data-for="${id}"]`).textContent = msg; }

  function showForm(m) {
    editingId = m ? m.menuId : null;
    el('formTitle').textContent = m ? `แก้ไขเมนู: ${m.name}` : 'เพิ่มเมนูใหม่';
    el('fStockLabel').textContent = m ? 'สต็อกคงเหลือ (สาขานี้)' : 'สต็อกเริ่มต้น (สาขานี้)';
    el('fName').value = m ? m.name : '';
    el('fCat').value = m ? String(m.categoryId) : '';
    el('fPrice').value = m ? m.price : '';
    el('fStock').value = m ? m.stock : 0;
    clearErrors();
    form.style.display = '';
    form.scrollIntoView({ behavior: 'smooth', block: 'center' });
    el('fName').focus();
  }
  function hideForm() { form.style.display = 'none'; editingId = null; }

  // ตรวจทันทีฝั่ง client (server ตรวจซ้ำอีกครั้ง)
  function validate() {
    clearErrors();
    let ok = true;
    const name = el('fName').value.trim();
    const price = Number(el('fPrice').value);
    const stock = Number(el('fStock').value);
    if (!name) { setErr('fName', 'กรุณากรอกชื่อเมนู'); ok = false; }
    if (!el('fCat').value) { setErr('fCat', 'กรุณาเลือกหมวดหมู่'); ok = false; }
    if (!(price > 0)) { setErr('fPrice', 'ราคาต้องเป็นตัวเลขมากกว่า 0'); ok = false; }
    if (!Number.isInteger(stock) || stock < 0) { setErr('fStock', 'ต้องเป็นจำนวนเต็มตั้งแต่ 0 ขึ้นไป'); ok = false; }
    return ok && { branchId, name, categoryId: Number(el('fCat').value), price, stock };
  }

  el('addBtn').addEventListener('click', () => showForm(null));
  el('cancelBtn').addEventListener('click', hideForm);

  form.addEventListener('submit', async (ev) => {
    ev.preventDefault();
    const body = validate();
    if (!body) return;
    el('saveBtn').disabled = true;
    App.setStatus(statusEl, 'info', 'กำลังบันทึก…');
    try {
      const r = editingId
        ? await App.api(`/menu/${editingId}`, { method: 'PUT', body })
        : await App.api('/menu', { method: 'POST', body });
      App.setStatus(statusEl, 'ok', r.message);
      hideForm();
      await load();
    } catch (e) {
      App.setStatus(statusEl, 'err', e.message);
    } finally {
      el('saveBtn').disabled = false;
    }
  });

  el('rows').addEventListener('click', async (e) => {
    const act = e.target.closest('[data-act]')?.dataset.act;
    const row = e.target.closest('tr[data-id]');
    if (!act || !row) return;
    const m = items.find((x) => x.menuId === Number(row.dataset.id));
    if (act === 'edit') return showForm(m);
    if (act === 'delete') {
      if (!confirm(`ลบเมนู "${m.name}" ออกจากทุกสาขาใช่หรือไม่?`)) return;
      try {
        const r = await App.api(`/menu/${m.menuId}?branchId=${branchId}`, { method: 'DELETE' });
        App.setStatus(statusEl, 'ok', r.message);
        await load();
      } catch (err) {
        App.setStatus(statusEl, 'err', err.message);
      }
    }
  });

  await load();
})();
