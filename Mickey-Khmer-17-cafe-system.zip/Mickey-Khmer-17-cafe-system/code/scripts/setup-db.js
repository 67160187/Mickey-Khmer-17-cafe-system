// scripts/setup-db.js — สร้างฐานข้อมูลใหม่ + ใส่ข้อมูลตัวอย่าง (รันซ้ำได้ ใช้ล้างข้อมูลก่อน demo)
//   npm run setup-db
require('dotenv').config();
const fs = require('fs');
const path = require('path');
const mysql = require('mysql2/promise');

const DB_NAME = process.env.DB_NAME || 'cafe_pos';
const TABLES = ['stock_movement', 'order_item', 'orders', 'branch_stock', 'menu_item', 'employee', 'branch', 'category'];

// แยกไฟล์ .sql เป็นทีละคำสั่ง (ตัด comment -- ออกก่อน)
function readStatements(file) {
  const sql = fs.readFileSync(file, 'utf8')
    .split('\n')
    .map((line) => line.replace(/--.*$/, ''))
    .join('\n');
  return sql.split(';').map((s) => s.trim()).filter(Boolean);
}

// ตัวสุ่มแบบกำหนด seed ได้ ทำให้ข้อมูลย้อนหลังออกมาเหมือนเดิมทุกครั้ง
function seededRandom(seed) {
  let s = seed;
  return () => {
    s = (s * 1103515245 + 12345) % 2147483648;
    return s / 2147483648;
  };
}

function toSqlDateTime(d) {
  const p = (n) => String(n).padStart(2, '0');
  return `${d.getFullYear()}-${p(d.getMonth() + 1)}-${p(d.getDate())} ${p(d.getHours())}:${p(d.getMinutes())}:${p(d.getSeconds())}`;
}

// สร้างประวัติการขาย 14 วันย้อนหลัง + ช่วงเช้าของวันนี้ (ไม่ตัดสต็อก เพราะสต็อกใน seed คือยอดคงเหลือปัจจุบัน)
async function insertSalesHistory(conn) {
  const rand = seededRandom(42);
  const [menus] = await conn.query('SELECT menu_id, price FROM menu_item');
  const [emps] = await conn.query('SELECT employee_id, branch_id FROM employee');
  const popularity = { 1: 2, 2: 3, 3: 5, 4: 4, 5: 2, 6: 4, 7: 2, 8: 2, 9: 1 };
  const weighted = menus.flatMap((m) => Array(popularity[m.menu_id] || 1).fill(m));
  const now = new Date();
  let count = 0;

  for (let daysAgo = 14; daysAgo >= 0; daysAgo--) {
    for (const branchId of [1, 2, 3]) {
      const staff = emps.filter((e) => Number(e.branch_id) === branchId);
      const ordersToday = daysAgo === 0 ? 2 + branchId : 5 + Math.floor(rand() * 6);
      for (let k = 0; k < ordersToday; k++) {
        const t = new Date(now);
        t.setDate(t.getDate() - daysAgo);
        if (daysAgo === 0) {
          // ออเดอร์ของวันนี้ ให้อยู่ก่อนเวลาปัจจุบันเสมอ
          t.setMinutes(t.getMinutes() - (k + 1) * 23 - branchId * 7);
          if (t.getDate() !== now.getDate()) continue;
        } else {
          t.setHours(7 + Math.floor(rand() * 12), Math.floor(rand() * 60), Math.floor(rand() * 60), 0);
        }
        const emp = staff[Math.floor(rand() * staff.length)];
        const pay = rand() < 0.55 ? 'CASH' : 'QR';
        const [o] = await conn.query(
          'INSERT INTO orders (employee_id, payment_method, created_at) VALUES (?, ?, ?)',
          [emp.employee_id, pay, toSqlDateTime(t)]);
        const lines = 1 + Math.floor(rand() * 3);
        const used = new Set();
        for (let l = 0; l < lines; l++) {
          const m = weighted[Math.floor(rand() * weighted.length)];
          if (used.has(m.menu_id)) continue;
          used.add(m.menu_id);
          const qty = 1 + Math.floor(rand() * 2);
          await conn.query(
            'INSERT INTO order_item (order_id, menu_id, quantity, unit_price) VALUES (?, ?, ?, ?)',
            [o.insertId, m.menu_id, qty, m.price]);
        }
        count++;
      }
    }
  }
  return count;
}

async function main() {
  const conn = await mysql.createConnection({
    host: process.env.DB_HOST || 'localhost',
    port: Number(process.env.DB_PORT || 3306),
    user: process.env.DB_USER || 'root',
    password: process.env.DB_PASSWORD || '',
  });

  console.log(`กำลังสร้างฐานข้อมูล ${DB_NAME} ...`);
  await conn.query(`CREATE DATABASE IF NOT EXISTS \`${DB_NAME}\` CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci`);
  await conn.query(`USE \`${DB_NAME}\``);
  await conn.query('SET FOREIGN_KEY_CHECKS = 0');
  for (const t of TABLES) await conn.query(`DROP TABLE IF EXISTS ${t}`);
  await conn.query('SET FOREIGN_KEY_CHECKS = 1');

  const dbDir = path.join(__dirname, '..', 'database');
  for (const stmt of readStatements(path.join(dbDir, 'schema.sql'))) await conn.query(stmt);
  for (const stmt of readStatements(path.join(dbDir, 'seed.sql'))) await conn.query(stmt);
  const n = await insertSalesHistory(conn);

  await conn.end();
  console.log(`เสร็จแล้ว: 3 สาขา, 6 พนักงาน, 9 เมนู, ประวัติการขาย ${n} ออเดอร์`);
  console.log('ต่อไปรัน: npm start แล้วเปิด http://localhost:' + (process.env.PORT || 3000));
}

main().catch((err) => {
  console.error('\nตั้งค่าฐานข้อมูลไม่สำเร็จ:', err.message);
  if (err.code === 'ECONNREFUSED') console.error('→ ยังไม่ได้เปิด MySQL (เช่น กด Start ที่ MySQL ใน XAMPP)');
  if (err.code === 'ER_ACCESS_DENIED_ERROR') console.error('→ ชื่อผู้ใช้/รหัสผ่าน MySQL ในไฟล์ .env ไม่ถูกต้อง');
  process.exit(1);
});
