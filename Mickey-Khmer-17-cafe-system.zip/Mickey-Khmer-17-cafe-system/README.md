# Brew & Bean POS — ระบบ POS ร้านกาแฟหลายสาขา (กลุ่ม 04)

ร้านกาแฟ "Brew & Bean" มี 3 สาขา เดิมใช้กระดาษจดออเดอร์และเครื่องคิดเลข ทำให้คิดเงินผิด ลืมท็อปปิ้ง และไม่รู้ล่วงหน้าว่าวัตถุดิบใกล้หมด
ระบบนี้ให้พนักงานกดเลือกเมนูจากหน้าจอ คำนวณราคาอัตโนมัติ ตัดสต็อกทันทีที่ยืนยันออเดอร์ และให้เจ้าของร้านเห็นยอดขายรวมทุกสาขาแบบเรียลไทม์

## สมาชิก

| ลำดับ | ชื่อ-นามสกุล | รหัสนักศึกษา | บทบาท |
|---|---|---|---|
| 1 | นายนพพร บุญรอด | 67160187 | Project Lead / PM |
| 2 | นายวชิรวิทย์ น้อมเจริญ | 67160043 | Business/System Analyst |
| 3 | นายนฤปนาท รื่นเริงใจ | 67160188 | Designer (UML/DB) |
| 4 | นายศตพร ขาวนก | 67160202 | Developer |
| 5 | นายชลทรัพย์ ชินปฐมพงค์ | 67160001 | Presenter / Documenter |

## เอกสารโครงงาน

- [Team Charter (wk01)](docs/wk01-team-charter.md)
- [Feasibility Report + BPMN As-Is/To-Be (wk02)](docs/wk02-feasibility-report.md)
- [Requirements (wk03)](docs/wk03-requirements.md)
- [User Stories + Use Case (wk04)](docs/wk04-user-stories.md)
- [Class Diagram (wk06)](docs/wk06-class-diagram.png) · [Object Diagram (wk06)](docs/wk06-object-diagram.png) · [Quiz Assignment (wk06)](docs/wk06-quiz-assignment.md)
- [ER Diagram (wk07)](docs/wk07-er-diagram.png) · [Schema SQL (wk07)](docs/wk07-schema.sql)
- [Sequence Diagram (wk09)](docs/wk09-sequence-diagram.png) · [Workshop (wk09)](docs/wk09-workshop.md)
- [Input/Output Design (wk10)](docs/wk10-input-output-design.docx) · [Wireframe (wk10)](docs/wk10-wireframe.docx)
- [Architecture (wk11)](docs/wk11-architecture.md) · [Diagram 1](docs/images/wk11-diagram-1.png) · [Diagram 2](docs/images/wk11-diagram-2.png)
- AI Disclosure: [wk05](docs/ai-disclosure/wk05-ai-disclosure.md) · [wk09](docs/ai-disclosure/wk09-ai-disclosure.md) · [wk10](docs/ai-disclosure/wk10-ai-disclosure.md)

## โครงสร้าง repository

```
├── code/                     ระบบที่ใช้งานได้จริง (Node.js + Express + MySQL)
│   ├── database/             schema.sql (จาก wk07) และ seed.sql (ข้อมูลตัวอย่าง)
│   ├── scripts/setup-db.js   สร้างฐานข้อมูล + ใส่ข้อมูลตัวอย่าง
│   ├── public/               หน้าจอ: เข้าสู่ระบบ, รับออเดอร์, ใบเสร็จ, จัดการเมนู, รายงานยอดขาย
│   └── src/                  routes / controllers / models / config (ตาม Architecture wk11)
├── docs/                     เอกสารทุกสัปดาห์ + images/ + ai-disclosure/
└── README.md
```

## วิธีติดตั้งและรัน

ต้องมี [Node.js](https://nodejs.org) 18 ขึ้นไป และ MySQL หรือ MariaDB (เช่น XAMPP)

1. เปิด MySQL (XAMPP Control Panel → Start ที่ MySQL)
2. เข้าโฟลเดอร์ `code/` แล้วติดตั้งแพ็กเกจ
   ```bash
   cd code
   npm install
   ```
3. คัดลอก `.env.example` เป็น `.env` แล้วแก้รหัสผ่าน MySQL ถ้ามี (XAMPP ปล่อยว่างได้)
4. สร้างฐานข้อมูลพร้อมข้อมูลตัวอย่าง (รันซ้ำเมื่อไหร่ก็ได้ เพื่อล้างข้อมูลกลับเป็นค่าเริ่มต้น)
   ```bash
   npm run setup-db
   ```
5. เปิดระบบ แล้วเข้า http://localhost:3000
   ```bash
   npm start
   ```

ข้อมูลตัวอย่างมี 3 สาขา (บางแสน, ศรีราชา, พัทยา) 6 พนักงาน 9 เมนู และประวัติการขายย้อนหลัง 14 วัน
สาขาบางแสนตั้งใจให้ "มัทฉะลาเต้" หมด และ "คาปูชิโน่" กับ "ครัวซองต์" ใกล้หมด เพื่อใช้สาธิตการแจ้งเตือน

## ฟีเจอร์ที่ทำได้ และ Requirement ที่รองรับ

| หน้าจอ / ฟีเจอร์ | Requirement / User Story |
|---|---|
| เข้าสู่ระบบด้วยบัญชีพนักงาน ยังไม่เข้าสู่ระบบจะถูกพากลับหน้าเข้าสู่ระบบ | FR-09, US-03 |
| รับออเดอร์แบบกดเลือกเมนู แยกหมวด ปรับจำนวนได้ | FR-01, US-01 |
| คำนวณยอดรวมอัตโนมัติ (server คิดราคาใหม่จากฐานข้อมูลเสมอ) | FR-03, US-01 |
| เมนูหมดสต็อกกดเลือกไม่ได้ และ server ปฏิเสธถ้าสต็อกไม่พอ | US-02 (Exception 2a) |
| ตัดสต็อกทันทีเมื่อยืนยันออเดอร์ ภายใน transaction เดียว พร้อมบันทึก stock_movement | FR-04 |
| แจ้งเตือนเมนูที่สต็อกเหลือน้อย (ค่าเริ่มต้น ≤ 10) | FR-05 |
| เลือกชำระเงินสด / QR Code (ต้องเลือกก่อนถึงกดยืนยันได้) | US-04 |
| ใบเสร็จ พิมพ์ได้ | FR-08, US-05 |
| รายงานยอดขายตามเมนู เทียบทุกสาขา และออเดอร์ล่าสุด อัปเดตอัตโนมัติทุก 5 วินาที | FR-06, FR-07 |
| จัดการเมนู เพิ่ม/แก้ไข/ลบ และปรับสต็อกรายสาขา | wk10 Wireframe หน้าจอที่ 2 |

## ข้อจำกัดของระบบ (สิ่งที่ยังไม่ได้ทำ)

- **ท็อปปิ้ง (FR-02)** ยังไม่รองรับ เพราะ schema wk07 ยังไม่มีตารางท็อปปิ้ง
- **ตัดสต็อกตามสูตรวัตถุดิบ** ตอนนี้ตัดสต็อกเป็นจำนวนแก้ว/ชิ้นของเมนู (ตาม `branch_stock` ใน wk07) ยังไม่ได้แตกเป็นวัตถุดิบ เช่น นม หรือเมล็ดกาแฟ
- **รหัสผ่าน bcrypt (NFR-05)** การเข้าสู่ระบบเป็นแบบเลือกชื่อพนักงาน ยังไม่มีรหัสผ่าน เพราะตาราง `employee` ยังไม่มีคอลัมน์รหัสผ่าน
- **ใบเสร็จดิจิทัลแบบ QR Code** ยังไม่ได้ทำ มีเฉพาะใบเสร็จที่พิมพ์ได้
- **การชำระเงินผ่าน QR** บันทึกเป็นวิธีชำระเงินเท่านั้น ยังไม่เชื่อมผู้ให้บริการชำระเงินจริง
- หลายสาขาจำลองด้วย `branch_id` บนฐานข้อมูลเดียวที่ localhost ตาม Physical View ใน wk11
